package com.example.pinyinoverlay

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import net.sourceforge.pinyin4j.PinyinHelper
import net.sourceforge.pinyin4j.format.HanyuPinyinCaseType
import net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat
import net.sourceforge.pinyin4j.format.HanyuPinyinToneType
import net.sourceforge.pinyin4j.format.HanyuPinyinVCharType

data class Item(val rect: Rect, val text: String)

class PinyinService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var overlay: OverlayView? = null

    private val fmt = HanyuPinyinOutputFormat().apply {
        toneType = HanyuPinyinToneType.WITH_TONE_MARK
        vCharType = HanyuPinyinVCharType.WITH_U_UNICODE
        caseType = HanyuPinyinCaseType.LOWERCASE
    }

    private val scanRunnable = Runnable { scan() }

    override fun onServiceConnected() {
        val view = OverlayView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(view, lp)
        overlay = view
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // aspetta che lo schermo si "calmi" prima di rileggere
        handler.removeCallbacks(scanRunnable)
        handler.postDelayed(scanRunnable, 250)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        overlay?.let {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it)
        }
        super.onDestroy()
    }

    private fun scan() {
        val root = rootInActiveWindow ?: return
        val items = mutableListOf<Item>()
        collect(root, items)
        overlay?.setItems(items)
    }

    private fun isChinese(c: Char) = c in '\u4e00'..'\u9fff'

    private fun collect(node: AccessibilityNodeInfo?, out: MutableList<Item>) {
        if (node == null || out.size >= 150) return
        if (node.isVisibleToUser) {
            val t = (node.text ?: node.contentDescription)?.toString()
            if (t != null && t.any { isChinese(it) }) {
                val r = Rect()
                node.getBoundsInScreen(r)
                if (r.width() > 0 && r.height() > 0) out.add(Item(r, toPinyin(t)))
            }
        }
        for (i in 0 until node.childCount) collect(node.getChild(i), out)
    }

    private fun toPinyin(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            if (isChinese(c)) {
                val p = try {
                    PinyinHelper.toHanyuPinyinStringArray(c, fmt)
                } catch (e: Exception) {
                    null
                }
                if (p != null && p.isNotEmpty()) sb.append(p[0]).append(' ') else sb.append(c)
            } else {
                sb.append(c)
            }
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }
}

class OverlayView(ctx: Context) : View(ctx) {
    private var items: List<Item> = emptyList()
    private val bg = Paint().apply { color = 0xCC000000.toInt() }
    private val fg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val loc = IntArray(2)

    init {
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    fun setItems(list: List<Item>) {
        items = list
        invalidate()
    }

    private fun sp(v: Float) =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)

    override fun onDraw(canvas: Canvas) {
        getLocationOnScreen(loc)
        val maxSize = sp(12f)
        val minSize = sp(8f)
        for (item in items) {
            fg.textSize = maxSize
            val w = fg.measureText(item.text)
            val avail = item.rect.width().toFloat()
            if (w > avail) fg.textSize = maxOf(minSize, maxSize * avail / w)

            val textW = fg.measureText(item.text)
            val h = fg.textSize + 6f
            val x = (item.rect.left - loc[0]).toFloat()
            var y = (item.rect.top - loc[1]).toFloat() - h
            if (y < 0f) y = (item.rect.top - loc[1]).toFloat()

            canvas.drawRect(x, y, x + textW + 8f, y + h, bg)
            canvas.drawText(item.text, x + 4f, y + h - 4f, fg)
        }
    }
}
