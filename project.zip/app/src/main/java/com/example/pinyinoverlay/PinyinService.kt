package com.example.pinyinoverlay

import android.accessibilityservice.AccessibilityService
import android.annotation.TargetApi
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextPaint
import android.text.TextUtils
import android.util.TypedValue
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import net.sourceforge.pinyin4j.PinyinHelper
import net.sourceforge.pinyin4j.format.HanyuPinyinCaseType
import net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat
import net.sourceforge.pinyin4j.format.HanyuPinyinToneType
import net.sourceforge.pinyin4j.format.HanyuPinyinVCharType
import java.util.concurrent.Executor

// source = testo cinese da tradurre (solo sulla prima riga di ogni blocco)
data class Item(val rect: RectF, val pinyin: String, val source: String?)

class PinyinService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var overlay: OverlayView? = null

    private var a11yItems: List<Item> = emptyList()
    private var ocrItems: List<Item> = emptyList()
    private var ocrBusy = false

    private val translations = HashMap<String, String>()
    private val pending = HashSet<String>()
    private var modelReady = false

    private val fmt = HanyuPinyinOutputFormat().apply {
        toneType = HanyuPinyinToneType.WITH_TONE_MARK
        vCharType = HanyuPinyinVCharType.WITH_U_UNICODE
        caseType = HanyuPinyinCaseType.LOWERCASE
    }

    private val translator by lazy {
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.CHINESE)
                .setTargetLanguage(TranslateLanguage.ITALIAN)
                .build()
        )
    }
    private val recognizer by lazy {
        TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
    }

    private val scanRunnable = Runnable { scan() }
    private val ocrRunnable = Runnable { runOcr() }

    override fun onServiceConnected() {
        val view = OverlayView(this) { translations[it] }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(view, lp)
        overlay = view

        // il modello di traduzione (circa 30 MB) si scarica una volta sola
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                modelReady = true
                scan()
            }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val t = event?.eventType
        if (t == AccessibilityEvent.TYPE_VIEW_SCROLLED ||
            t == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        ) {
            // schermata cambiata: i riquadri letti dalle foto non valgono più
            if (ocrItems.isNotEmpty()) {
                ocrItems = emptyList()
                push()
            }
        }
        handler.removeCallbacks(scanRunnable)
        handler.postDelayed(scanRunnable, 350)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        overlay?.let {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it)
        }
        super.onDestroy()
    }

    // ---------- lettura dei testi (accessibilità) ----------

    private fun scan() {
        val root = rootInActiveWindow ?: return
        val items = mutableListOf<Item>()
        collect(root, items)
        a11yItems = items
        push()
        handler.removeCallbacks(ocrRunnable)
        handler.postDelayed(ocrRunnable, 700)
    }

    private fun isChinese(c: Char) = c in '\u4e00'..'\u9fff'
    private fun hasChinese(s: String) = s.any { isChinese(it) }

    private fun collect(node: AccessibilityNodeInfo?, out: MutableList<Item>) {
        if (node == null || out.size >= 120) return
        if (node.isVisibleToUser && !node.isPassword) {
            val t = node.text?.toString()?.take(100)
            if (t != null && hasChinese(t)) addLines(node, t, out)
        }
        for (i in 0 until node.childCount) collect(node.getChild(i), out)
    }

    @Suppress("DEPRECATION")
    private fun charRects(node: AccessibilityNodeInfo, len: Int): Array<RectF?>? {
        val result = arrayOfNulls<RectF>(len)
        var start = 0
        while (start < len) {
            val count = minOf(
                AccessibilityNodeInfo.EXTRA_DATA_TEXT_CHARACTER_LOCATION_ARG_MAX_LENGTH,
                len - start
            )
            val args = Bundle().apply {
                putInt(AccessibilityNodeInfo.EXTRA_DATA_TEXT_CHARACTER_LOCATION_ARG_START_INDEX, start)
                putInt(AccessibilityNodeInfo.EXTRA_DATA_TEXT_CHARACTER_LOCATION_ARG_LENGTH, count)
            }
            if (!node.refreshWithExtraData(
                    AccessibilityNodeInfo.EXTRA_DATA_TEXT_CHARACTER_LOCATION_KEY, args
                )
            ) return null
            val arr = node.extras.getParcelableArray(
                AccessibilityNodeInfo.EXTRA_DATA_TEXT_CHARACTER_LOCATION_KEY
            ) ?: return null
            for (k in arr.indices) {
                if (start + k < len) result[start + k] = arr[k] as? RectF
            }
            start += count
        }
        return result
    }

    private fun addLines(node: AccessibilityNodeInfo, text: String, out: MutableList<Item>) {
        var firstEmitted = false
        fun emitLine(rect: RectF, s: String) {
            if (!hasChinese(s)) return
            out.add(Item(RectF(rect), toPinyin(s), if (!firstEmitted) text else null))
            firstEmitted = true
        }

        val rects = charRects(node, text.length)
        if (rects == null) {
            val r = Rect()
            node.getBoundsInScreen(r)
            if (r.width() > 0 && r.height() > 0) emitLine(RectF(r), text)
            return
        }
        var start = -1
        var line = RectF()
        for (i in text.indices) {
            val r = rects[i] ?: continue
            if (r.isEmpty) continue
            if (start >= 0 && Math.abs(r.centerY() - line.centerY()) > line.height() * 0.6f) {
                emitLine(line, text.substring(start, i))
                start = -1
            }
            if (start < 0) {
                start = i
                line = RectF(r)
            } else {
                line.union(r)
            }
        }
        if (start >= 0) emitLine(line, text.substring(start))
    }

    // ---------- lettura delle foto (screenshot + OCR) ----------

    @TargetApi(30)
    private fun runOcr() {
        if (Build.VERSION.SDK_INT < 30 || ocrBusy) return
        ocrBusy = true
        val exec = Executor { handler.post(it) }
        takeScreenshot(
            Display.DEFAULT_DISPLAY,
            exec,
            object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                    val hb = result.hardwareBuffer
                    val hw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                    val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    hb.close()
                    if (bmp == null) {
                        ocrBusy = false
                        return
                    }
                    recognizer.process(InputImage.fromBitmap(bmp, 0))
                        .addOnSuccessListener { t ->
                            ocrItems = ocrToItems(t)
                            push()
                        }
                        .addOnCompleteListener {
                            ocrBusy = false
                            bmp.recycle()
                        }
                }

                override fun onFailure(errorCode: Int) {
                    ocrBusy = false
                }
            }
        )
    }

    private fun ocrToItems(t: Text): List<Item> {
        val out = mutableListOf<Item>()
        for (block in t.textBlocks) {
            val blockText = block.lines.joinToString("") { it.text }.take(200)
            var first = true
            for (line in block.lines) {
                val box = line.boundingBox ?: continue
                if (!hasChinese(line.text)) continue
                out.add(Item(RectF(box), toPinyin(line.text), if (first) blockText else null))
                first = false
            }
        }
        return out
    }

    // ---------- unione dei risultati, traduzione, pinyin ----------

    private fun overlapsMostly(a: RectF, b: RectF): Boolean {
        val r = RectF()
        if (!r.setIntersect(a, b)) return false
        return r.width() * r.height() > 0.3f * a.width() * a.height()
    }

    private fun push() {
        // le righe delle foto che coincidono con testo già letto vengono scartate
        val keep = ocrItems.filter { o -> a11yItems.none { overlapsMostly(o.rect, it.rect) } }
        val all = a11yItems + keep
        all.forEach { it.source?.let { s -> requestTranslation(s) } }
        overlay?.setItems(all)
    }

    private fun requestTranslation(src: String) {
        if (!modelReady || translations.containsKey(src) || pending.size >= 20) return
        if (!pending.add(src)) return
        if (translations.size > 300) translations.clear()
        translator.translate(src)
            .addOnSuccessListener {
                translations[src] = it
                pending.remove(src)
                overlay?.invalidate()
            }
            .addOnFailureListener {
                translations[src] = ""
                pending.remove(src)
            }
    }

    private fun toPinyin(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            if (isChinese(c)) {
                val p = try {
                    PinyinHelper.toHanyuPinyinStringArray(c, fmt)
                } catch (e: Exception) {
                    null
                }
                if (p != null && p.isNotEmpty()) sb.append(p[0]).append(' ') else sb.append(c)
            } else {
                sb.append(c)
            }
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }
}

// ---------- grafica ----------

class OverlayView(ctx: Context, private val lookup: (String) -> String?) : View(ctx) {
    private var items: List<Item> = emptyList()

    private val card = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xEB161B2E.toInt() }
    private val accent = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF7C9CFF.toInt() }
    private val pinyinPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val itPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFC857.toInt()
        typeface = Typeface.create("sans-serif", Typeface.ITALIC)
    }
    private val loc = IntArray(2)

    init {
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    fun setItems(list: List<Item>) {
        items = list
        invalidate()
    }

    private fun sp(v: Float) =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)

    override fun onDraw(canvas: Canvas) {
        getLocationOnScreen(loc)
        val d = resources.displayMetrics.density
        val margin = 4f * d
        val bar = 3f * d
        val leftPad = 4f * d + bar + 4f * d
        val rightPad = 6f * d
        val vPad = 4f * d
        val gap = 1f * d
        val radius = 8f * d

        pinyinPaint.textSize = sp(11f)
        itPaint.textSize = sp(10f)
        val h1 = pinyinPaint.descent() - pinyinPaint.ascent()
        val h2 = itPaint.descent() - itPaint.ascent()
        val maxText = minOf(width - 2 * margin - leftPad - rightPad, 280f * d)
        if (maxText <= 0f) return

        val drawn = ArrayList<RectF>()
        for (item in items) {
            val py = TextUtils.ellipsize(item.pinyin, pinyinPaint, maxText, TextUtils.TruncateAt.END).toString()
            val tr = item.source?.let { lookup(it) }?.takeIf { it.isNotBlank() }
                ?.let { TextUtils.ellipsize(it, itPaint, maxText, TextUtils.TruncateAt.END).toString() }

            val textW = maxOf(pinyinPaint.measureText(py), tr?.let { itPaint.measureText(it) } ?: 0f)
            val cw = leftPad + textW + rightPad
            val ch = vPad * 2 + h1 + (if (tr != null) gap + h2 else 0f)

            var x = item.rect.centerX() - loc[0] - cw / 2f
            x = x.coerceIn(margin, maxOf(margin, width - cw - margin))
            var y = item.rect.top - loc[1] - ch - 2f * d
            if (y < margin) y = item.rect.bottom - loc[1] + 2f * d

            val box = RectF(x, y, x + cw, y + ch)
            if (drawn.any { RectF.intersects(it, box) }) continue
            drawn.add(box)

            canvas.drawRoundRect(box, radius, radius, card)
            val bx = x + 4f * d
            canvas.drawRoundRect(RectF(bx, y + vPad, bx + bar, y + ch - vPad), bar / 2f, bar / 2f, accent)

            val tx = x + leftPad
            canvas.drawText(py, tx, y + vPad - pinyinPaint.ascent(), pinyinPaint)
            if (tr != null) {
                canvas.drawText(tr, tx, y + vPad + h1 + gap - itPaint.ascent(), itPaint)
            }
        }
    }
}
