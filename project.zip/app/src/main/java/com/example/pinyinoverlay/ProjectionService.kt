package com.example.pinyinoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager

// Tiene aperta la "registrazione schermo" e conserva l'ultimo fotogramma,
// che il servizio di accessibilità legge con l'OCR (serve solo su Android 10 e precedenti).
class ProjectionService : Service() {

    companion object {
        @Volatile
        var instance: ProjectionService? = null
        private const val CHANNEL = "capture"
    }

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vdisplay: VirtualDisplay? = null
    private var held: Image? = null

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data: Intent? = intent?.getParcelableExtra("data")
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        startAsForeground()

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)
        projection = p
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                release(false)
                stopSelf()
            }
        }, main)

        val dm = DisplayMetrics()
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        val r = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 3)
        reader = r
        r.setOnImageAvailableListener({ rd ->
            val img = try {
                rd.acquireLatestImage()
            } catch (e: Exception) {
                null
            }
            if (img != null) {
                held?.close()
                held = img
            }
        }, main)
        vdisplay = p.createVirtualDisplay(
            "pinyin-capture", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, main
        )
        instance = this
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Lettura foto", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Pinyin Overlay")
            .setContentText("Lettura dei testi nelle foto attiva")
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    // Ultimo fotogramma dello schermo come bitmap (o null se non c'è ancora)
    fun capture(): Bitmap? {
        val img = held ?: return null
        return try {
            val plane = img.planes[0]
            val w = img.width
            val h = img.height
            val rowPadding = plane.rowStride - plane.pixelStride * w
            val buf = plane.buffer
            buf.rewind()
            val wide = Bitmap.createBitmap(w + rowPadding / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
            wide.copyPixelsFromBuffer(buf)
            if (rowPadding == 0) {
                wide
            } else {
                Bitmap.createBitmap(wide, 0, 0, w, h).also { wide.recycle() }
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun release(stopProjection: Boolean) {
        instance = null
        held?.close()
        held = null
        vdisplay?.release()
        vdisplay = null
        reader?.close()
        reader = null
        val p = projection
        projection = null
        if (stopProjection) p?.stop()
    }

    override fun onDestroy() {
        release(true)
        super.onDestroy()
    }
}
