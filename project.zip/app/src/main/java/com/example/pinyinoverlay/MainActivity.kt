package com.example.pinyinoverlay

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        layout.addView(TextView(this).apply {
            text = "Attiva \"Pinyin Overlay\" tra i servizi installati in Accessibilità. " +
                    "Poi metti il telefono in cinese e vedrai pinyin e traduzione in italiano sopra i testi.\n\n" +
                    "La prima volta serve internet per scaricare il dizionario di traduzione (circa 30 MB)."
            textSize = 16f
        })
        layout.addView(Button(this).apply {
            text = "Apri impostazioni accessibilità"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })
        setContentView(layout)
    }
}
