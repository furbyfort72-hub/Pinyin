package com.example.pinyinoverlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private val reqCapture = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        layout.addView(TextView(this).apply {
            text = "1) Attiva \"Pinyin Overlay\" tra i servizi installati in Accessibilità.\n\n" +
                    "2) Per leggere anche i testi nelle foto, tocca \"Attiva lettura foto\" e conferma: " +
                    "Android mostra un'icona mentre lo schermo viene letto.\n\n" +
                    "La prima volta serve internet per scaricare il dizionario di traduzione (circa 30 MB)."
            textSize = 16f
        })
        layout.addView(Button(this).apply {
            text = "Apri impostazioni accessibilità"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })
        layout.addView(Button(this).apply {
            text = "Attiva lettura foto"
            setOnClickListener {
                val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
            }
        })
        layout.addView(Button(this).apply {
            text = "Ferma lettura foto"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ProjectionService::class.java))
            }
        })
        setContentView(layout)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, ProjectionService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
        }
    }
}
